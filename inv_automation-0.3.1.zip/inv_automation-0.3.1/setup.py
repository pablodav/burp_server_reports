#! python3
# Help from: http://www.scotttorborg.com/python-packaging/minimal.html
# https://docs.python.org/3.4/tutorial/modules.html
# Install it with python setup.py install
# Or use: python setup.py develop (changes to the source files will be immediately available)

from setuptools import setup

setup(name='inv_automation',
      version='0.3.1',
      description='Inventory automation from servers list',
      url='http://10.100.66.79/infra/ansible.git',
      author='Pablo Estigarribia',
      author_email='pablo.estigarribia@visitor.upm.com',
      license='priv',
      packages=['inv_automation'],
      zip_safe=False)

