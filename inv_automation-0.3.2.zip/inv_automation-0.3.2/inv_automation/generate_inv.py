#! python3

import configparser
import os
from inv_automation.workbook_servers import excel_get_dict


def get_config_file(config_file):
    # Help from: https://docs.python.org/3.4/library/configparser.html
    config = configparser.ConfigParser(allow_no_value=True)
    config.read(config_file)
    return config


def parse_inventory(winconfig_file, lnxconfig_file, inventory):
    winconfig = {}
    lnxconfig = {}
    winconfig = get_config_file(winconfig_file)
    lnxconfig = get_config_file(lnxconfig_file)
    print(list(winconfig))
    print(list(lnxconfig))

    default_sections = {'windows2008': '2008',
                        'windows2012': '2012',
                        'hosts_addresses': 'linux'}

    file = 'C:/Users/v744989/SharePoint/Databases - Bases de datos de infor 1/server_list-v6.13.xlsx'
    servers = excel_get_dict(file, 'Servers', 'Name')
    """ Get dict from excel file, sheet, with 'Name' column as key
    and create nested dict for each row by 'Name'. """

    os_category = 'OS Category'
    os_version = 'SO - version'

    for k in servers:
        # Add windows servers to inventory
        client_os_cat = str(servers[k].get(os_category)).lower()
        client_os_ver = str(servers[k].get(os_version)).lower()
        client_ip = str(servers[k].get('IP')).lower()
        domain = str(servers[k].get('domain')).lower()
        client_status = str(servers[k].get('status')).lower()
        client_inventory = str(servers[k].get('inventory', '')).lower()
        client = str(k.lower()).strip()
        client_ip = client_ip.strip()

        if client_os_ver and client_os_cat and client_ip and client_status == 'active' \
                and inventory in client_inventory:  # Go if has requirements

            for section, find_string in sorted(default_sections.items()):  # Check the client for each section

                if find_string in client_os_ver:
                    if 'windows' in client_os_cat:
                        config_file = winconfig
                        children_group_os = 'windows'
                        if 'l224' in client:
                            section += '_dmz'
                            children_group_os += '_dmz'
                        if "griffin" not in domain:
                            section += '_non_griffin'
                            children_group_os += '_non_griffin'
                        children_group = children_group_os + ':children'
                    elif 'linux' in client_os_cat:
                        config_file = lnxconfig

                    if not config_file.has_section(section):
                        config_file.add_section(section)
                    if not config_file.has_option(section, client):
                        if "griffin" not in domain:
                            config_file[section][client + '    ansible_ssh_host'] = client_ip
                        else:
                            config_file[section][client] = None

                    if 'windows' in client_os_cat:
                        if not config_file.has_section(children_group):  # Adds to children of windows group
                            config_file.add_section(children_group)
                        if not config_file.has_option(children_group, section):
                            config_file[children_group][section] = None  # Adds to children of windows group
                        winconfig = config_file
                    elif 'linux' in client_os_cat:
                        lnxconfig = config_file

        else:
            print("client {} with status: {},  not has all requirements \n"
                  "   IP: {},    OS_CAT: {},    OS_VER: {}"
                  " Inventory: {}".format(k, client_status,
                                          client_ip, client_os_cat, client_os_ver,
                                          client_inventory))

    with open(winconfig_file, 'w') as configfile:
        winconfig.write(configfile, space_around_delimiters=False)

    with open(lnxconfig_file, 'w') as configfile:
        lnxconfig.write(configfile, space_around_delimiters=False)


win_config_dir = '../../ansible_windows'
lnx_config_dir = '../../linux_servers'

inventories = ['production', 'stage']

for i in range(len(inventories)):
    win_file = os.path.join(win_config_dir, inventories[i])
    lnx_file = os.path.join(lnx_config_dir, inventories[i])
    parse_inventory(win_file, lnx_file, inventories[i])











    # Add new server to section without value:
    # config["windows2012"]["l240srv345"] = {}
